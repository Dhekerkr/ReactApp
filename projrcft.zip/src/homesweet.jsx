import React,{useState} from "react";
import Recipe from "./recipe";
import { recipes } from "./data";

function Homesweet(){
    return(
        <>
            {recipes.map((item)=>(
                <Recipe
                    key={item.id}
                    title={item.title}
                    image={item.image}
                    category={item.category}
                    ingredients={item.ingredients}
                    instructions={item.instructions}
                     />
            ))           
            }
        </>
    )
}
export default Homesweet;