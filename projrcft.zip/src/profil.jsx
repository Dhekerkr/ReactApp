import { useParams } from "react-router-dom";

const Profil = ({ recipes }) => {
  const { id } = useParams();  // Get the ID from the URL
  console.log("ID from URL:", id);  
  const person = people.find(p => p.id === parseInt(id)); // Find the person using the ID

  if (!person) {
    return <p>Person not found</p>;
  }

  console.log("Person:", person); // Log the person to make sure it's correct

  // Filter recipes based on the person's id
  const userRecipes = recipes.filter((recipe) => recipe.idp === person.id);

  console.log("Filtered Recipes:", userRecipes); // Log the filtered recipes

  return (
    <div>
      <h2>{person.firstName} {person.lastName}</h2>
      <h3>Email: {person.email}</h3>
      <h3>Phone: {person.phone}</h3>
      <h3>Address: {person.address}</h3>
      <h3>Age: {person.age}</h3>
      <h3>Gender: {person.gender}</h3>

      <h4>Recipes:</h4>
      {userRecipes.length > 0 ? (
        userRecipes.map((recipe) => (
          <div key={recipe.id}>
            <h5>{recipe.title}</h5>
            <p>Category: {recipe.category}</p>
            <img src={recipe.image} alt={recipe.title} />
          </div>
        ))
      ) : (
        <p>No recipes available.</p>
      )}
    </div>
  );
};

export default Profil;
