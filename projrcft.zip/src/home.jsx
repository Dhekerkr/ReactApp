import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Recipe Manager</h1>
      <p>Explore recipes and view profiles.</p>
    </div>
  );
};

export default Home;
