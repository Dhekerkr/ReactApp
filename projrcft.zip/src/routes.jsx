import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./navbar"; // Import Navbar
import Home from "./home"; // Import Home component
import Profil from "./profil"; // Import Profil component
import Homesweet from "./homesweet";

const AppRoutes = () => {
  return (
    <Router>
      {/* Add the Navbar */}
      <Navbar />

      {/* Define Routes */}
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/profile" element={<Profil />} />
        <Route path="/sweet" element={<Homesweet />}/>
    
      </Routes>
    </Router>
  );
};

export default AppRoutes;
