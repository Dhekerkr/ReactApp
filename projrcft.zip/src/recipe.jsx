import React from "react";

function Recipe({id,idp,title,category,ingredients,instructions,image}){
    return(
        <div>
            <h3>{title}</h3>
            <img src={image} alt={title} />
            <h5>{category}</h5>
            <h5>{ingredients}</h5>
            <h5>{instructions}</h5>
        </div>
    )
}
export default Recipe;