export const people=[
    {
      "id": 1,
      "firstName": "John",
      "lastName": "Doe",
      "email": "john.doe@example.com",
      "phone": "+1-555-123-4567",
      "address": "123 Main St, New York, NY 10001",
      "age": 30,
      "gender": "Male"
    },
    {
      "id": 2,
      "firstName": "Jane",
      "lastName": "Smith",
      "email": "jane.smith@example.com",
      "phone": "+1-555-987-6543",
      "address": "456 Elm St, Los Angeles, CA 90001",
      "age": 25,
      "gender": "Female"
    },
    {
      "id": 3,
      "firstName": "Michael",
      "lastName": "Brown",
      "email": "michael.brown@example.com",
      "phone": "+1-555-456-7890",
      "address": "789 Oak St, Chicago, IL 60601",
      "age": 35,
      "gender": "Male"
    },
    {
      "id": 4,
      "firstName": "Emily",
      "lastName": "Johnson",
      "email": "emily.johnson@example.com",
      "phone": "+1-555-321-1234",
      "address": "321 Pine St, Houston, TX 77001",
      "age": 28,
      "gender": "Female"
    },
    {
      "id": 5,
      "firstName": "David",
      "lastName": "Williams",
      "email": "david.williams@example.com",
      "phone": "+1-555-654-3210",
      "address": "654 Cedar St, Phoenix, AZ 85001",
      "age": 40,
      "gender": "Male"
    }
  ]
  