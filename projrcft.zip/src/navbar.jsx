import React, { useState } from "react";
import { Link } from "react-router-dom"; // Import Link for navigation
import './navbar.css'; // Import your CSS

const Navbar = () => {
  const [homeDropdownOpen, setHomeDropdownOpen] = useState(false);

  const toggleHomeDropdown = () => {
    setHomeDropdownOpen(!homeDropdownOpen);
  };

  return (
    <nav className="navbar">
      <ul className="nav-list">
        {/* Home with Dropdown */}
        <li
          className="nav-item nav-dropdown"
          onMouseEnter={toggleHomeDropdown}
          onMouseLeave={toggleHomeDropdown}
        >
          <span className="nav-link"><a href="home">Home</a></span>
          {homeDropdownOpen && (
            <ul className="dropdown-menu">
              <li className="dropdown-item">
                <a href="salty-spicy" className="dropdown-link">Salty/Spicy</a>
              </li>
              <li className="dropdown-item">
                <a href="sweet" className="dropdown-link">Sweet</a>
              </li>
            </ul>
          )}
        </li>

        {/* Profile Link */}
        <li className="nav-item">
          <Link to="/profile/1" className="nav-link">Profile</Link>
        </li>

        {/* Add New Recipe Link */}
        <li className="nav-item">
          <Link to="/add-recipe" className="nav-link">Add New Recipe</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
